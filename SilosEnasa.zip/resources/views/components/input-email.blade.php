<label class="text-blue">Correo eléctronico</label>
<div class="input-group mb-3">
    <div class="input-group-prepend">
        <span class="input-group-text"><i class="fas fa-envelope text-blue"></i></span>
    </div>
    <input type="email" class="form-control" placeholder="Email">
</div>
