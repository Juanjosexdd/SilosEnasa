require('./bootstrap');

require('alpinejs');
window.Swal = require('sweetalert2');

